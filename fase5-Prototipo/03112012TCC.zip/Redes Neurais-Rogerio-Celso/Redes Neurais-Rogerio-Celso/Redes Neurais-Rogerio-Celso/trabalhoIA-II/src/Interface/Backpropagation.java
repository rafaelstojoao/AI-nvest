package Interface;
import Apoio.Filtro;
import Apoio.Funcoes;
import Estruturas.camadaEntrada;
import Estruturas.camadaOculta;
import Estruturas.camadaSaida;
import Estruturas.neuronioEntrada;
import Estruturas.neuronioOculta;
import Estruturas.neuronioSaida;
import java.awt.Cursor;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class Backpropagation extends javax.swing.JFrame {
        //Criando 3 camadas vazias
        camadaEntrada entrada = new camadaEntrada();
        camadaOculta oculta = new camadaOculta();
        camadaSaida saida = new camadaSaida();
        String relatorio="";

    /** Creates new form tela */
    public Backpropagation() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupoOpçao = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jQtdeOculta = new javax.swing.JTextField();
        jQtdeSaida = new javax.swing.JTextField();
        jQtdeEntrada = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jCriarPesos = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jPesosOculta = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        jPesosSaida = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jCaminhoArquivo = new javax.swing.JTextField();
        jProcurarArquivo = new javax.swing.JButton();
        jAbrirArquivo = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jTaxaAprendizado = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jOpFuncaoTransferencia = new javax.swing.JComboBox();
        jPanel7 = new javax.swing.JPanel();
        jErroMaximo = new javax.swing.JTextField();
        jMaxIteracoes = new javax.swing.JTextField();
        jOpErroMax = new javax.swing.JRadioButton();
        jOpMaxI = new javax.swing.JRadioButton();
        jLabel7 = new javax.swing.JLabel();
        jAplicar = new javax.swing.JButton();
        jTreinarRede = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jCaminhoSimula = new javax.swing.JTextField();
        jProcurarArquivoTeste = new javax.swing.JButton();
        jTestar = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jMatrizConfusao = new javax.swing.JTable();
        jScrollPane4 = new javax.swing.JScrollPane();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Redes Neurais");

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Quantidades de Neurônios"));

        jQtdeSaida.setEditable(false);

        jQtdeEntrada.setEditable(false);

        jLabel1.setText(" Entrada");

        jLabel2.setText("Oculta");

        jLabel3.setText("Saída");

        jCriarPesos.setText("Gerar Pesos");
        jCriarPesos.setEnabled(false);
        jCriarPesos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCriarPesosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jQtdeEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel2)
                    .addComponent(jQtdeOculta, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jCriarPesos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jQtdeSaida, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(2, 2, 2))
                    .addComponent(jLabel2)
                    .addComponent(jLabel1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jQtdeEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jQtdeOculta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jQtdeSaida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jCriarPesos)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Pesos Iniciais"));

        jPesosOculta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jPesosOculta);

        jPesosSaida.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {}
            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jPesosSaida);

        jLabel4.setText("Neurônios - Camada Oculta");

        jLabel5.setText("Neurônios - Camada de Saída");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 531, Short.MAX_VALUE)
                    .addComponent(jLabel4)
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel5Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jScrollPane1, jScrollPane2});

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Arquivo de Treinamento"));

        jProcurarArquivo.setText("procurar...");
        jProcurarArquivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jProcurarArquivoActionPerformed(evt);
            }
        });

        jAbrirArquivo.setText("abrir");
        jAbrirArquivo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAbrirArquivoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jCaminhoArquivo, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jProcurarArquivo))
                    .addComponent(jAbrirArquivo, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jProcurarArquivo)
                    .addComponent(jCaminhoArquivo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jAbrirArquivo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Taxa de Aprendizado"));

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTaxaAprendizado, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(92, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jTaxaAprendizado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Função de Transferência"));

        jOpFuncaoTransferencia.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Linear", "Logística", "Tangente Hip." }));
        jOpFuncaoTransferencia.setSelectedIndex(1);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel9Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jOpFuncaoTransferencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addComponent(jOpFuncaoTransferencia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Critério de parada"));

        jErroMaximo.setEditable(false);

        grupoOpçao.add(jOpErroMax);
        jOpErroMax.setText("Erro por ciclo");
        jOpErroMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOpErroMaxActionPerformed(evt);
            }
        });

        grupoOpçao.add(jOpMaxI);
        jOpMaxI.setText("Iterações");
        jOpMaxI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jOpMaxIActionPerformed(evt);
            }
        });

        jLabel7.setForeground(new java.awt.Color(1, 1, 1));
        jLabel7.setText("Escolha um dos métodos:");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jOpMaxI)
                    .addComponent(jMaxIteracoes, javax.swing.GroupLayout.PREFERRED_SIZE, 102, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jOpErroMax)
                    .addComponent(jErroMaximo, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jErroMaximo, jMaxIteracoes});

        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(jOpMaxI)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jMaxIteracoes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jOpErroMax)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jErroMaximo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );

        jAplicar.setText("Aplicar Pesos");
        jAplicar.setEnabled(false);
        jAplicar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jAplicarActionPerformed(evt);
            }
        });

        jTreinarRede.setText("Treinar Rede");
        jTreinarRede.setEnabled(false);
        jTreinarRede.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTreinarRedeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addContainerGap())
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jAplicar)
                    .addComponent(jTreinarRede)))
            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jAplicar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jTreinarRede))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanel2.getAccessibleContext().setAccessibleName("Quantidade de Neurônios");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Treinamento", jPanel1);

        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Arquivo de Treinamento"));

        jProcurarArquivoTeste.setText("procurar...");
        jProcurarArquivoTeste.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jProcurarArquivoTesteActionPerformed(evt);
            }
        });

        jTestar.setText("Testar");
        jTestar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTestarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(jCaminhoSimula, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jProcurarArquivoTeste))
                    .addComponent(jTestar, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCaminhoSimula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jProcurarArquivoTeste))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTestar)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Matriz de Confusão"));

        jMatrizConfusao.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {}
            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(jMatrizConfusao);

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 449, Short.MAX_VALUE)
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(115, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(318, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Teste", jPanel6);

        jLabel9.setForeground(new java.awt.Color(1, 1, 1));
        jLabel9.setText("Desenvolvido por Celso Umeki e Rogério Oyama");
        jLabel9.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jScrollPane4.setViewportView(jLabel9);

        jTabbedPane1.addTab("Sobre", jScrollPane4);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 742, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 24, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
  
    //Carrega os pesos que estão na interface de tabela p/ camada oculta
    private ArrayList<Float> carregarPesosInterfaceEntradaOculta(int linha){
        ArrayList<Float> pesosEO = new ArrayList<Float>();
        for (int i = 0; i < jPesosOculta.getColumnCount(); i++) {
            pesosEO.add(Float.parseFloat(jPesosOculta.getValueAt(linha, i).toString()));
        }
        return pesosEO;
    }

    //Carrega os pesos que estão na interface de tabela p/ camada DE SAIDA
    private ArrayList<Float> carregarPesosInterfaceOcultaSaida(int linha){
        ArrayList<Float> pesosOS = new ArrayList<Float>();
        for (int i = 0; i < jPesosSaida.getColumnCount(); i++) {
            pesosOS.add(Float.parseFloat(jPesosSaida.getValueAt(linha, i).toString()));
        }
        return pesosOS;
    }

    private void jProcurarArquivoTesteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jProcurarArquivoTesteActionPerformed
        JFileChooser fc = new JFileChooser("c:\\");
        fc.addChoosableFileFilter(new Filtro("csv"));
        fc.showOpenDialog(fc);
        File myFile = fc.getSelectedFile();
        jCaminhoSimula.setText(myFile.getAbsolutePath());
}//GEN-LAST:event_jProcurarArquivoTesteActionPerformed


    private void jTestarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTestarActionPerformed
    //Testar a rede e gerar a matriz de confusao
        File myFile = new File(jCaminhoSimula.getText());

        int quant_arquivo = 0;
        try {
            quant_arquivo = Funcoes.getQuantidadeLinhas(myFile);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Cria matriz de confusao e inicializa com zeros
        int[][] matriz_confusao = new int[saida.getQuantidade()][saida.getQuantidade()];        
        for(int k=0; k<saida.getQuantidade(); k++){
            for (int m=0; m<saida.getQuantidade(); m++)
                matriz_confusao[k][m]=0;
        }

        int indice_linha = 2;
        while (indice_linha <= quant_arquivo) {

            ArrayList<neuronioEntrada> itensE = null;
            //Lendo uma linha inteira do arquivo
            try {
                //Adiciona itens da linha em uma lista de itens da camada de entrada
                itensE = Funcoes.getLinha(myFile, indice_linha);
            } catch (FileNotFoundException ex) {
                Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
            }

            //pegar valor desejado na lista  (classe esperada - último item da linha)
            float desejado = itensE.get(itensE.size() - 1).getValorEntrada();

            //retira o valor classe e deixa somente os itens
            itensE.remove(itensE.size() - 1);

            //atribui os itens lidos do arquivo à camada de entrada
            entrada.setItensEntrada(itensE);

            //criando vetor de desejados de acordo com a classe esperada
            int[] vetor_desejados = new int[saida.getQuantidade()];
            for (int k = 0; k < saida.getQuantidade(); k++) {
                /*caso a opçao de funcao de transferencia seja tg. hiperbólica, os valores
                 * desejados devem ser -1 ou 1*/
                if (jOpFuncaoTransferencia.getSelectedIndex() == 2) {
                    vetor_desejados[k] = -1;
                } //caso seja linear ou logistica, valores sao 0 e 1
                else {
                    vetor_desejados[k] = 0;
                }
            }
            vetor_desejados[(int) desejado - 1] = 1;

         //Calcula os nets da camada oculta
            for (int i = 0; i < oculta.getQuantidade(); i++) {
                neuronioOculta aux = oculta.getItensOculta().get(i);
                float net = aux.calculaNetOculta(entrada, aux);
                oculta.getItensOculta().get(i).setNetOculta(net);           
            }

         //Aplica a funcao de transferencia para obter a saida da camada oculta
            for (int i = 0; i < oculta.getQuantidade(); i++) {
                float net = (oculta.getItensOculta().get(i).getNetOculta());
                switch (jOpFuncaoTransferencia.getSelectedIndex()) {
                    case 0:
                        oculta.getItensOculta().get(i).setValorOculta(Funcoes.appTransfLinear((net)));
                        break;
                    case 1:
                        oculta.getItensOculta().get(i).setValorOculta(Funcoes.appTransfLogistica(net));
                        break;
                    case 2:
                        oculta.getItensOculta().get(i).setValorOculta(Funcoes.appTransfTgHiperbolica((net)));
                        break;
                }       
            }

         //Calcular nets da camada de saída
            for (int i = 0; i < saida.getQuantidade(); i++) {
                neuronioSaida aux = saida.getItensSaida().get(i);
                float net = (aux.calculaNetSaida(oculta, aux));
                saida.getItensSaida().get(i).setNetSaida(net);            
            }

         //Calcula saída da camada de saída 
            float[] saida_real = new float[saida.getQuantidade()];
            for (int i = 0; i < saida.getQuantidade(); i++) {
                float net = (saida.getItensSaida().get(i).getNetSaida());
                switch (jOpFuncaoTransferencia.getSelectedIndex()) {
                    case 0:
                        saida.getItensSaida().get(i).setValorSaida(Funcoes.appTransfLinear((net)));
                        break;
                    case 1:
                        saida.getItensSaida().get(i).setValorSaida(Funcoes.appTransfLogistica(net));
                        break;
                    case 2:
                        saida.getItensSaida().get(i).setValorSaida(Funcoes.appTransfTgHiperbolica((net)));
                        break;
                }
                saida_real[i]=saida.getItensSaida().get(i).getValorSaida(); //insere da rede no vetor

             }
            
            //Pegar valor obtido e inserir na matriz de confusao
            int classe_final = Funcoes.getClasseSaidaFinal(saida_real);
            matriz_confusao[(int)desejado-1][classe_final-1]++ ;

            indice_linha++;
        }

        //criar interface para matriz de confusao
        Vector colunas = new Vector();
        Vector dados = new Vector();
        colunas.add(0, "-");
        for (int k = 0; k < saida.getQuantidade(); k++) {
                String aux="Cl. ".concat(String.valueOf(k+1));
                colunas.add(aux);
                dados.addElement(new Vector());                
                ((Vector) dados.lastElement()).addElement(aux);

                for (int m = 0; m < saida.getQuantidade(); m++) {
                    ((Vector) dados.lastElement()).addElement(matriz_confusao[k][m]);
                } 
        }
 
        DefaultTableModel tab_confusao = new DefaultTableModel(dados, colunas){            
            @Override ////celulas nao editaveis
            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return false;
            }
        };
        jMatrizConfusao.setModel(tab_confusao);
     /////fim da interface para matriz de confusao
        //exibe detalhes do teste na tela
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy - hh:mm a");

    }//GEN-LAST:event_jTestarActionPerformed

    private void jTreinarRedeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTreinarRedeActionPerformed
        Cursor cursor = Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
        this.setCursor(cursor); //cursor de espera do mouse

        File myFile = new File(jCaminhoArquivo.getText());


        int quant_arquivo = 0;
        try {
            quant_arquivo = Funcoes.getQuantidadeLinhas(myFile);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Opcoes de parada
        float erro_max = Float.MIN_VALUE;
        int max_iteracoes = Integer.MAX_VALUE;
        float taxa_aprendizado = Float.parseFloat(jTaxaAprendizado.getText()); //Taxa escolhida

        //Seleciona o valor do critério de parada escolhido pelo usuario
        if (jOpErroMax.isSelected()) {
            erro_max = Float.parseFloat(jErroMaximo.getText());
        } else if (jOpMaxI.isSelected()) {
            max_iteracoes = Integer.parseInt(jMaxIteracoes.getText());
        }


        int continua = 1;
        float erro_max_ciclo = Float.MIN_VALUE;

        try {
            while (continua <= max_iteracoes) {
                int indice_linha = 2;
                erro_max_ciclo = Float.MIN_VALUE;
                float desejado;

                while (indice_linha <= quant_arquivo) {
                    ArrayList<neuronioEntrada> itensE = null;
                    try {
                        itensE = Funcoes.getLinha(myFile, indice_linha);
                    } catch (FileNotFoundException ex) {
                        Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (IOException ex) {
                        Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    desejado = itensE.get(itensE.size() - 1).getValorEntrada();
                    itensE.remove(itensE.size() - 1);
                    entrada.setItensEntrada(itensE);
                    int[] vetor_desejados = new int[saida.getQuantidade()];
                    for (int k = 0; k < saida.getQuantidade(); k++) {
                        if (jOpFuncaoTransferencia.getSelectedIndex() == 2) {
                            vetor_desejados[k] = -1;
                        }
                        else {
                            vetor_desejados[k] = 0;
                        }
                    }
                    vetor_desejados[(int) desejado - 1] = 1;

                    //Calcula os nets da camada oculta
                    for (int i = 0; i < oculta.getQuantidade(); i++) {
                        neuronioOculta aux = oculta.getItensOculta().get(i);
                        float net = aux.calculaNetOculta(entrada, aux);
                        oculta.getItensOculta().get(i).setNetOculta(net);
                    }

                    //Aplica a funcao de transferencia para obter saida da camada oculta
                    for (int i = 0; i < oculta.getQuantidade(); i++) {
                        float net = (oculta.getItensOculta().get(i).getNetOculta());
                        switch (jOpFuncaoTransferencia.getSelectedIndex()) {
                            case 0: //Linear
                                oculta.getItensOculta().get(i).setValorOculta(Funcoes.appTransfLinear((net)));
                                break;
                            case 1: //Logistica
                                oculta.getItensOculta().get(i).setValorOculta(Funcoes.appTransfLogistica(net));
                                break;
                            case 2:    //tangente hiperbólica
                                oculta.getItensOculta().get(i).setValorOculta(Funcoes.appTransfTgHiperbolica((net)));
                                break;
                        }
                    }

                    //Calcular nets da saída
                    for (int i = 0; i < saida.getQuantidade(); i++) {
                        neuronioSaida aux = saida.getItensSaida().get(i);
                        float net = (aux.calculaNetSaida(oculta, aux));
                        saida.getItensSaida().get(i).setNetSaida(net);
                    }

                    //Calcula saída da camada de saida
                    for (int i = 0; i < saida.getQuantidade(); i++) {
                        float net = (saida.getItensSaida().get(i).getNetSaida());
                        switch (jOpFuncaoTransferencia.getSelectedIndex()) {
                            case 0:
                                saida.getItensSaida().get(i).setValorSaida(Funcoes.appTransfLinear((net)));
                                break;
                            case 1:
                                saida.getItensSaida().get(i).setValorSaida(Funcoes.appTransfLogistica(net));
                                break;
                            case 2:
                                saida.getItensSaida().get(i).setValorSaida(Funcoes.appTransfTgHiperbolica((net)));
                                break;
                        }
                    }

                    //Calcula-se os erros da saída
                    for (int i = 0; i < saida.getQuantidade(); i++) {
                        float erro = 0;
                        float net = (saida.getItensSaida().get(i).getNetSaida());
                        float obtido = saida.getItensSaida().get(i).getValorSaida();
                        switch (jOpFuncaoTransferencia.getSelectedIndex()) {
                            case 0:
                                erro = (vetor_desejados[i] - obtido) * Funcoes.appDerivadaTransfLinear(net);
                                break;
                            case 1:
                                erro = (vetor_desejados[i] - obtido) * Funcoes.appDerivadaTransfLogistica(net);
                                break;
                            case 2:
                                erro = ((vetor_desejados[i] - obtido) * Funcoes.appDerivadaTransfTgHiperbolica((net)));
                                break;
                        }
                        saida.getItensSaida().get(i).setErroSaida((erro));
                    }
                    
                    //Calcula-se os erros da camada oculta
                    for (int i = 0; i < oculta.getQuantidade(); i++) {
                        float erro = 0;                     
                        float net = (oculta.getItensOculta().get(i).getNetOculta());
                        float soma = 0;
                        for (int j = 0; j < saida.getQuantidade(); j++) {
                            float erro_parcial = saida.getItensSaida().get(j).getErroSaida();             
                            float peso_os = saida.getItensSaida().get(j).getPesosOcultaSaida().get(i);
                            soma = soma + erro_parcial * peso_os;
                        }
                        switch (jOpFuncaoTransferencia.getSelectedIndex()) {
                            case 0:
                                erro = (Funcoes.appDerivadaTransfLinear(net)) * soma;
                                break;
                            case 1:
                                erro = (Funcoes.appDerivadaTransfLogistica(net)) * soma;
                                break;
                            case 2:
                                erro = (Funcoes.appDerivadaTransfTgHiperbolica(net)) * soma;
                                break;
                        }
                        oculta.getItensOculta().get(i).setErroOculta((erro));
                    }

                    //Atualiza os pesos da camada de saida
                    for (int i = 0; i < saida.getQuantidade(); i++) { 
                        for (int j = 0; j < oculta.getQuantidade(); j++) {
                            float peso_atual = saida.getItensSaida().get(i).getPesosOcultaSaida().get(j);
                            float erro_neuronio = saida.getItensSaida().get(i).getErroSaida();
                            float saida_oculta = oculta.getItensOculta().get(j).getValorOculta();
                            float peso_novo = (peso_atual + taxa_aprendizado * erro_neuronio * saida_oculta);
                            saida.getItensSaida().get(i).getPesosOcultaSaida().set(j, peso_novo);
                        }
                    }

                    ///Atualiza os pesos da camada oculta
                    for (int i = 0; i < oculta.getQuantidade(); i++) {
                        for (int j = 0; j < entrada.getQuantidade(); j++) {
                            float peso_atual = oculta.getItensOculta().get(i).getPesosEntradaOculta().get(j);
                            float erro_neuronio = oculta.getItensOculta().get(i).getErroOculta();
                            float saida_entrada = entrada.getItensEntrada().get(j).getValorEntrada();
                            float peso_novo = (peso_atual + taxa_aprendizado * erro_neuronio * saida_entrada);
                            oculta.getItensOculta().get(i).getPesosEntradaOculta().set(j, peso_novo);
                        }
                    }

                    //Calcular erro da rede
                    float soma = 0;
                    for (int i = 0; i < saida.getQuantidade(); i++) {
                        soma = soma + saida.getItensSaida().get(i).getErroSaida();
                    }
                    float erro_desta = ((float) 0.5 * (soma * soma));
                    if (erro_desta > erro_max_ciclo) { 
                        erro_max_ciclo = erro_desta;
                    }
                    indice_linha++;
                }
                if ((erro_max_ciclo < erro_max) && jOpErroMax.isSelected()) {
                    relatorio = relatorio.concat("**Erro máximo após a iteracao " + continua + " = " + erro_max_ciclo + "\n");
                    break;
                }
                relatorio = relatorio.concat("**Erro máximo após a iteracao " + continua + " = " + erro_max_ciclo + "\n");

                continua++;
            }

            cursor = Cursor.getDefaultCursor(); //volta o mouse ao formato original
            this.setCursor(cursor);

        } catch (java.lang.NumberFormatException ex) {
            cursor = Cursor.getDefaultCursor();
            this.setCursor(cursor);
        }
    }//GEN-LAST:event_jTreinarRedeActionPerformed

    private void jAplicarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAplicarActionPerformed
        jTreinarRede.setEnabled(true);

        //Atribuindo os pesos à camada oculta
        ArrayList<neuronioOculta> itensOc = new ArrayList<neuronioOculta>();
        for (int i = 0; i < oculta.getQuantidade(); i++) {
            neuronioOculta itemOc = new neuronioOculta();
            ArrayList<Float> pesosEO = carregarPesosInterfaceEntradaOculta(i);
            itemOc.setPesosEntradaOculta(pesosEO); 
            itensOc.add(itemOc);
        }
        oculta.setItensOculta(itensOc);

        //Atribuindo os pesos à camada de saída
        ArrayList<neuronioSaida> itensS = new ArrayList<neuronioSaida>();
        for (int i = 0; i < saida.getQuantidade(); i++) {
            neuronioSaida itemS = new neuronioSaida();
            ArrayList<Float> pesosSO = carregarPesosInterfaceOcultaSaida(i);
            itemS.setPesosOcultaSaida(pesosSO);
            itensS.add(itemS);
        }
        saida.setItensSaida(itensS);
    }//GEN-LAST:event_jAplicarActionPerformed

    private void jOpMaxIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOpMaxIActionPerformed
        jErroMaximo.setEditable(false);
        jMaxIteracoes.setEditable(true);
    }//GEN-LAST:event_jOpMaxIActionPerformed

    private void jOpErroMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jOpErroMaxActionPerformed
        jMaxIteracoes.setEditable(false);
        jErroMaximo.setEditable(true);
    }//GEN-LAST:event_jOpErroMaxActionPerformed

    private void jAbrirArquivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jAbrirArquivoActionPerformed
        jCriarPesos.setEnabled(true);
        File myFile = new File(jCaminhoArquivo.getText());
        int qtde_campos = 0;
        try {
            qtde_campos = Funcoes.getQuantidadeCampos(myFile);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        }
        int qtde_entrada = qtde_campos - 1;
        jQtdeEntrada.setText(String.valueOf(qtde_entrada));

        int qtde_saidas = 0;
        try {
            qtde_saidas = Funcoes.getQuantidadeSaidas(myFile);//retorna qtde de saídas de acordo com o arquivo
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Backpropagation.class.getName()).log(Level.SEVERE, null, ex);
        }
        jQtdeSaida.setText(String.valueOf(qtde_saidas)); //insere na interface

        jQtdeOculta.setText(String.valueOf(Funcoes.qtdeNeuroniosOculta(qtde_entrada, qtde_saidas)));

        //Alterando as quantidades de neuronios das camadas
        oculta.setQuantidade(Integer.parseInt(jQtdeOculta.getText()));
        saida.setQuantidade(Integer.parseInt(jQtdeSaida.getText()));
        entrada.setQuantidade(Integer.parseInt(jQtdeEntrada.getText()));
    }//GEN-LAST:event_jAbrirArquivoActionPerformed

    private void jProcurarArquivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jProcurarArquivoActionPerformed
        //Abrir arquivo
        JFileChooser fc = new JFileChooser("c:\\");
        fc.addChoosableFileFilter(new Filtro("csv"));
        fc.showOpenDialog(fc);
        File myFile = fc.getSelectedFile();
        jCaminhoArquivo.setText(myFile.getAbsolutePath());
    }//GEN-LAST:event_jProcurarArquivoActionPerformed

    private void jCriarPesosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCriarPesosActionPerformed
        //Cria pesos aleatórios
        jAplicar.setEnabled(true);

        Vector colunas = new Vector();
        Vector dados = new Vector();
        int j = 0;

        oculta.setQuantidade(Integer.parseInt(jQtdeOculta.getText()));
        ArrayList<Float> pesosEO = new ArrayList<Float>();    
        int k;
        for (k = 0; k < entrada.getQuantidade(); k++) {
            colunas.add(k);
        }
        for (k = 0; k < oculta.getQuantidade(); k++) {
            dados.addElement(new Vector());
            for (j = 0; j < entrada.getQuantidade(); j++) {
                pesosEO.add(Funcoes.randPeso());
                float aux = pesosEO.get(j);
                ((Vector) dados.lastElement()).addElement(String.valueOf(aux));
            }
            pesosEO.clear();
        }
        DefaultTableModel pesosOculta = new DefaultTableModel(dados, colunas);
        jPesosOculta.setModel(pesosOculta);

        colunas = new Vector();
        dados = new Vector();
        j = 0;
        ArrayList<Float> pesosOS = new ArrayList<Float>();
        for (k = 0; k < oculta.getQuantidade(); k++) {
            colunas.add(k);
        }

        for (k = 0; k < saida.getQuantidade(); k++) {
            dados.addElement(new Vector());
            for (j = 0; j < oculta.getQuantidade(); j++) {
                pesosOS.add(Funcoes.randPeso()); 
                float aux = pesosOS.get(j);
                ((Vector) dados.lastElement()).addElement(String.valueOf(aux));
            }
            pesosOS.clear();
        }
        DefaultTableModel pesosSaida = new DefaultTableModel(dados, colunas);
        jPesosSaida.setModel(pesosSaida);
    }//GEN-LAST:event_jCriarPesosActionPerformed
   
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Backpropagation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup grupoOpçao;
    private javax.swing.JButton jAbrirArquivo;
    private javax.swing.JButton jAplicar;
    private javax.swing.JTextField jCaminhoArquivo;
    private javax.swing.JTextField jCaminhoSimula;
    private javax.swing.JButton jCriarPesos;
    private javax.swing.JTextField jErroMaximo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTable jMatrizConfusao;
    private javax.swing.JTextField jMaxIteracoes;
    private javax.swing.JRadioButton jOpErroMax;
    private javax.swing.JComboBox jOpFuncaoTransferencia;
    private javax.swing.JRadioButton jOpMaxI;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTable jPesosOculta;
    private javax.swing.JTable jPesosSaida;
    private javax.swing.JButton jProcurarArquivo;
    private javax.swing.JButton jProcurarArquivoTeste;
    private javax.swing.JTextField jQtdeEntrada;
    private javax.swing.JTextField jQtdeOculta;
    private javax.swing.JTextField jQtdeSaida;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTaxaAprendizado;
    private javax.swing.JButton jTestar;
    private javax.swing.JButton jTreinarRede;
    // End of variables declaration//GEN-END:variables

}
