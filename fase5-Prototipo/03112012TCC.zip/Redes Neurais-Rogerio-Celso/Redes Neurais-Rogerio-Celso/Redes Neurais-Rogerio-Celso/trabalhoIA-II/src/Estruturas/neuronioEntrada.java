package Estruturas;

public class neuronioEntrada {
    private float valorEntrada;

    public neuronioEntrada(float valorEntrada) {
        this.valorEntrada = valorEntrada;
    }

    public neuronioEntrada() {
    }

    public float getValorEntrada() {
        return valorEntrada;
    }

    public void setValorEntrada(float valorEntrada) {
        this.valorEntrada = valorEntrada;
    }
}
