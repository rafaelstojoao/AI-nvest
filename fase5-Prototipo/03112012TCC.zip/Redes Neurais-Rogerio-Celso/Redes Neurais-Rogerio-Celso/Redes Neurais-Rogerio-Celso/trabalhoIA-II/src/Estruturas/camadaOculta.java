package Estruturas;
import java.util.ArrayList;

public class camadaOculta {
    private int quantidade;
    private ArrayList<neuronioOculta> itensOculta; //itens da entrada são inteiros

    public camadaOculta() {
    }

    public camadaOculta(int quantidade, ArrayList<neuronioOculta> itensOculta) {
        this.quantidade = quantidade;
        this.itensOculta = itensOculta;
    }

    public ArrayList<neuronioOculta> getItensOculta() {
        return itensOculta;
    }

    public void setItensOculta(ArrayList<neuronioOculta> itensOculta) {
        this.itensOculta = itensOculta;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}
