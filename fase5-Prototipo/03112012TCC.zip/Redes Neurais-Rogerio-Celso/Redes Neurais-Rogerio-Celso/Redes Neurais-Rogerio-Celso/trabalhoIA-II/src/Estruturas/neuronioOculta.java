package Estruturas;
import java.util.ArrayList;

public class neuronioOculta {
    float valorOculta;
    float netOculta;
    float erroOculta;
    ArrayList<Float> pesosEntradaOculta;

    public neuronioOculta(float valorOculta, float netOculta, ArrayList<Float> pesosEntradaOculta) {
        this.valorOculta = valorOculta;
        this.netOculta = netOculta;
        this.pesosEntradaOculta = pesosEntradaOculta;
    }

    public neuronioOculta() {
    }
     
    public float calculaNetOculta(camadaEntrada entrada, neuronioOculta itemOc) {
        float net=0;
        for(int i=0; i<entrada.getQuantidade(); i++){
                net = net+
                        entrada.getItensEntrada().get(i).getValorEntrada() * itemOc.getPesosEntradaOculta().get(i);
        }
        return net;
    }

    public float getErroOculta() {
        return erroOculta;
    }

    public void setErroOculta(float erroOculta) {
        this.erroOculta = erroOculta;
    }

    public float getNetOculta() {
        return netOculta;
    }

    public void setNetOculta(float netOculta) {
        this.netOculta = netOculta;
    }

    public ArrayList<Float> getPesosEntradaOculta() {
        return pesosEntradaOculta;
    }

    public void setPesosEntradaOculta(ArrayList<Float> pesosEntradaOculta) {
        this.pesosEntradaOculta = pesosEntradaOculta;
    }

    public float getValorOculta() {
        return valorOculta;
    }

    public void setValorOculta(float valorOculta) {
        this.valorOculta = valorOculta;
    }
}
