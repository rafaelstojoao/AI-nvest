package Estruturas;
import java.util.ArrayList;

public class camadaSaida {
    private int quantidade;
    private ArrayList<neuronioSaida> itensSaida; //itens da entrada são inteiros

    public camadaSaida() {
    }

    public camadaSaida(int quantidade, ArrayList<neuronioSaida> itensSaida) {
        this.quantidade = quantidade;
        this.itensSaida = itensSaida;
    }

    public ArrayList<neuronioSaida> getItensSaida() {
        return itensSaida;
    }

    public void setItensSaida(ArrayList<neuronioSaida> itensSaida) {
        this.itensSaida = itensSaida;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}
