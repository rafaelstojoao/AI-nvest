package Estruturas;
import java.util.ArrayList;

public class neuronioSaida {
    float valorSaida;
    float netSaida;
    float erroSaida;
    ArrayList<Float> pesosOcultaSaida;

    public neuronioSaida() {
    }

    public float getErroSaida() {
        return erroSaida;
    }

    public void setErroSaida(float erroSaida) {
        this.erroSaida = erroSaida;
    }

   public float calculaNetSaida(camadaOculta oculta, neuronioSaida itemS) {
     float net= 0;
     for(int i=0; i<oculta.getQuantidade(); i++){
                net = net+ oculta.getItensOculta().get(i).getValorOculta() * itemS.getPesosOcultaSaida().get(i);
     }
       
     return net;
     }

    public neuronioSaida(float valorSaida, float netSaida, ArrayList<Float> pesosOcultaSaida) {
        this.valorSaida = valorSaida;
        this.netSaida = netSaida;
        this.pesosOcultaSaida = pesosOcultaSaida;
    }

   
    public float getNetSaida() {
        return netSaida;
    }

    public void setNetSaida(float netSaida) {
        this.netSaida = netSaida;
    }

    public ArrayList<Float> getPesosOcultaSaida() {
        return pesosOcultaSaida;
    }

    public void setPesosOcultaSaida(ArrayList<Float> pesosOcultaSaida) {
        this.pesosOcultaSaida = pesosOcultaSaida;
    }

    public float getValorSaida() {
        return valorSaida;
    }

    public void setValorSaida(float valorSaida) {
        this.valorSaida = valorSaida;
    }
}
