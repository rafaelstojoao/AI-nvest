
package Estruturas;
import java.util.ArrayList;

public class camadaEntrada {
    private int quantidade;
    private ArrayList<neuronioEntrada> itensEntrada; //itens da entrada são inteiros

    public camadaEntrada() {
      
    }
    public camadaEntrada(int quantidade, ArrayList<neuronioEntrada> itensEntrada) {
        this.quantidade = quantidade;
        this.itensEntrada = itensEntrada;
    }

    public ArrayList<neuronioEntrada> getItensEntrada() {
        return itensEntrada;
    }

    public void setItensEntrada(ArrayList<neuronioEntrada> itensEntrada) {
        this.itensEntrada = itensEntrada;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }
}
