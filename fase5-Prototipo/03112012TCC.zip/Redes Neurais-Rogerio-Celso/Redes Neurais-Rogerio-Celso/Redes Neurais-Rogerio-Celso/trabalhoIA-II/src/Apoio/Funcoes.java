package Apoio;
import Estruturas.neuronioEntrada;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Random;

//Classe de funcoes auxiliares
public class Funcoes {

    public static int getClasseSaidaFinal(float[] saida_real) {
        float maior = Float.MIN_VALUE;
        int idx_maior = 0;
        for (int i = 0; i < saida_real.length; i++) {
            if (saida_real[i] > maior) {
                maior = saida_real[i]; idx_maior = i + 1;
            }
        }
        return idx_maior;
    }

    ///Precisão 3 casas decimais
    public static float setPrecisaoSimples(float valor) {
        String aux = String.valueOf(valor);
        BigDecimal bd = new BigDecimal(aux);
        bd = bd.setScale(3, BigDecimal.ROUND_HALF_DOWN);
        return (bd.floatValue());
    }

    public static Float appTransfLinear(Float net) {
        return net;
    }

    public static float appDerivadaTransfLinear(Float net) {
        return 1f;
    }

    public static float appTransfLogistica(Float net) {
        double aux = (1 / (1 + (Math.exp(-net))));
        return (float) aux;
    }

    public static float appDerivadaTransfLogistica(Float net) {
        float retorno = appTransfLogistica(net) * (1 - appTransfLogistica(net));
        return retorno;
    }

    public static float appTransfTgHiperbolica(float net) {
        double aux = ((1 - Math.exp(-2 * net)) / (1 + Math.exp(-2 * net)));
        return (float) aux;

    }

    public static float appDerivadaTransfTgHiperbolica(float net) {
        return (float) (1 - (appTransfTgHiperbolica(net) * (appTransfTgHiperbolica(net))));
    }

    //Gera pesos aleatórios
    public static float randPeso() {
        Random r = new Random();
        float ret = r.nextFloat();
        float sinal;
        if (r.nextInt() % 2 == 0) {
            sinal = -1;
        } else {
            sinal = 1;
        }
        return setPrecisaoSimples(ret * sinal);
    }

    //Calcula a quantidade de neurônios
    public static int qtdeNeuroniosOculta(int qtde_entrada, int qtde_saida) {
        float raiz = (qtde_entrada * qtde_saida);
        raiz = (float) Math.sqrt(raiz);
        return (int) raiz;
    }

    //Lê a quantidade de campos em uma linha do arquivo .csv
    public static int getQuantidadeCampos(File myFile) throws FileNotFoundException, IOException {
        FileReader reader = null;
        reader = new FileReader(myFile);
        BufferedReader leitor = new BufferedReader(reader);
        String linha = "", campos[] = null;
        linha = leitor.readLine();
        campos = linha.split(",");
        reader.close();
        leitor.close();
        return campos.length;
    }

    public static int getQuantidadeSaidas(File myFile) throws FileNotFoundException, IOException {
        FileReader reader = null;
        reader = new FileReader(myFile);
        BufferedReader leitor = new BufferedReader(reader);
        String linha = "", linhafinal[] = null, aux = "";
        int maior = 0;
        linha = leitor.readLine();
        while (linha != null) {
            linha = leitor.readLine();
            if (linha != null) {
                linhafinal = linha.split(",");
            }
            for (int i = 0; i < linhafinal.length; i++) {
                if (aux != null) 
                    aux = linhafinal[i];                
            }
            if (Integer.parseInt(aux) > maior)
                maior = Integer.parseInt(aux);            
        }
        reader.close();
        leitor.close();
        return maior;
    }

    public static ArrayList<neuronioEntrada> getLinha(File myFile, int indice_linha) throws FileNotFoundException, IOException {
        ArrayList<neuronioEntrada> itensE = new ArrayList<neuronioEntrada>();
        FileReader reader = null;
        reader = new FileReader(myFile);
        BufferedReader leitor = new BufferedReader(reader);
        String linha = "", campos[] = null;


        for (int i = 0; i < indice_linha; i++) { 
            linha = leitor.readLine();
            campos = linha.split(",");
        }

        for (int i = 0; i < campos.length; i++) {
            neuronioEntrada item = new neuronioEntrada(Float.parseFloat(campos[i]));
            itensE.add(item);
        }
        reader.close();
        leitor.close();
        return itensE;
    }

    //Determina a quantidade de linhas do arquivo
    public static int getQuantidadeLinhas(File myFile) throws FileNotFoundException, IOException {
        int quant = 0;
        FileReader reader = null;
        reader = new FileReader(myFile);
        BufferedReader leitor = new BufferedReader(reader);
        String linha = "";
        
        while (linha != null) {
            linha = leitor.readLine();
            if (linha != null) 
                quant++;            
        }
        return quant;
    }
}