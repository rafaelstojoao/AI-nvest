package Apoio;
import java.io.File;
import javax.swing.filechooser.FileFilter;

//Filtro para arquivos .csv
public class Filtro extends FileFilter {

    public String tipo;
    public Filtro(String tipo) {
        this.tipo = tipo;
    }
    
    public String getTipo() {
        return tipo;
    }
    
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean accept(File f) {
        return f.getName().toLowerCase().endsWith(tipo)|| f.isDirectory();
    }

    public String getDescription() {
        return "Arquivos " +tipo;
    }
}

