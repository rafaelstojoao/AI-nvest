<?php include("header.php");?>
<div class="container">
		<ul class="nav nav-tabs">
  			<li class="active">
    			<a href="#">Sobre o Sistema</a>
  			</li>
  			<li><a href="#">Como Utilizar</a></li>
  			<li><a href="#">Créditos</a></li>
		</ul>

<?php

include("footer.php");
?>

