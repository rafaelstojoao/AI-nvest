<?php 
	include("header.php");
	include "functions/banco.php";  
	$Obj_Conexao = new CONEXAO();
?>
<div class="container">
		<ul class="nav nav-tabs">
  			<li class="active">
    			<a href="#">Configurações da Rede Neural</a>
  			</li>

		</ul>

		<?php
		if(isset($_POST["btnFuncao"])){
				 $funcao =$_POST["optionsRadios"];
				 $funcTipo = ($funcao ==1)?'Tangente Hiperbólica':'Sigmóide';

				 if($Obj_Conexao->Altera("UPDATE funcTransferencia set atvFunc=0 ") && $Obj_Conexao->Altera("UPDATE funcTransferencia set atvFunc=1 WHERE idFunc=$funcao ")) 
					echo "    <div class='alert alert-success'><button class='close' data-dismiss='alert' type='button'>×</button>Função <strong>".$funcTipo."</strong> Selecionada Com <strong>Sucesso</strong>! </div>";
				else echo "    <div class='alert alert-error'><button class='close' data-dismiss='alert' type='button'>×</button>Função Não Pôde Ser Alterada... Tente Novamente! </div>";
		
				}

		if(isset($_POST["btnTX"])){
				 $valor =$_POST["txValor"];

				if($Obj_Conexao->Altera("INSERT INTO txAprendizado(dtTaxa,valorTaxa) VALUES(NOW(),'$valor')")) 
					echo "    <div class='alert alert-success'><button class='close' data-dismiss='alert' type='button'>×</button>Valor da Taxa de Aprendizado <strong>Alterada com Sucesso</strong>! </div>";
				else echo "    <div class='alert alert-error'><button class='close' data-dismiss='alert' type='button'>×</button>Valor da Taxa de Aprendizado Não Foi Alterada... Tente Novamente! </div>";
		}
		if(isset($_POST["btnTxErro"])){
				 $valor =$_POST["txErro"];

				if($Obj_Conexao->Altera("INSERT INTO txErro(dtTaxa,txErro) VALUES(NOW(),'$valor')")) 
					echo "    <div class='alert alert-success'><button class='close' data-dismiss='alert' type='button'>×</button>Valor da Taxa de Erro <strong>Alterada com Sucesso</strong>! </div>";
				else echo "    <div class='alert alert-error'><button class='close' data-dismiss='alert' type='button'>×</button>Valor da Taxa de Erro Não Foi Alterada... Tente Novamente! </div>";
		}
		if(isset($_POST["btnNeuronios"])){
				 $valor =$_POST["nNeuronios"];

				if($Obj_Conexao->Altera("INSERT INTO numNeuronios(dataAuteracao,numNeuronios) VALUES(NOW(),'$valor')")) 
					echo "    <div class='alert alert-success'><button class='close' data-dismiss='alert' type='button'>×</button>Número de Neurônios <strong>Alterado com Sucesso</strong>! </div>";
				else echo "    <div class='alert alert-error'><button class='close' data-dismiss='alert' type='button'>×</button>Número de Neurônios Não Foi Alterado... Tente Novamente! </div>";
		}
		?>

<div class="accordion" id="accordion2">

 	<div class="accordion-group">
    	<div class="accordion-heading">
       		<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion0" href="#collapseZero">
         		Definir Taxa de Erro Máximo Permitido 
       		</a>
  		</div>
 		<div id="collapseZero" class="accordion-body collapse">
 			<div class="accordion-inner">
				<?php 
				 		
					$pega_dados = $Obj_Conexao->Consulta("select * from txErro ORDER BY idtxErro DESC ");
					$linha = mysql_fetch_array($pega_dados);
				?>
				<form style="    margin: 10px;" action="#" method="post">
					<h1><i>&delta;</i> = 
						<input type="text" name="txErro" placeholder="<?php echo $linha[1]; ?>" style="    font-size: 24px;    height: 30px; width: 106px;   line-height: 20px;    margin-bottom: 0;    padding: 0 6px;"> 
						<input type="submit" class="btn btn-success"  value="Redefinir" name="btnTxErro">
					</h1>
				</form>
 			</div>
 		</div>
	</div>

 	<div class="accordion-group">
    	<div class="accordion-heading">
       		<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion1" href="#collapseOne">
         		Definir Neurônios da Camada Oculta 
       		</a>
  		</div>
 		<div id="collapseOne" class="accordion-body collapse">
 			<div class="accordion-inner">
				<?php 
				 		
					$pega_dados = $Obj_Conexao->Consulta("select * from numNeuronios ORDER BY idConfig DESC ");
					$linha = mysql_fetch_array($pega_dados);
				?>
				<form style="    margin: 10px;" action="#" method="post">
					<h1><i>&Theta;</i> = 
						<input type="text" name="nNeuronios" placeholder="<?php echo $linha[1]; ?>" style="    font-size: 24px;    height: 30px; width: 76px;   line-height: 20px;    margin-bottom: 0;    padding: 0 6px;"> 
						<input type="submit" class="btn btn-success"  value="Redefinir" name="btnNeuronios">
					</h1>
				</form>
 			</div>
 		</div>
	</div>
	<div class="accordion-group">
		<div class="accordion-heading">
			<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion2" href="#collapseTwo">
				Definir Taxa de Aprendizado
			</a>
		</div>
		<div id="collapseTwo" class="accordion-body collapse">
			<div class="accordion-inner">
				<?php 
				 		
					$pega_dados = $Obj_Conexao->Consulta("select * from txAprendizado ORDER BY idtx DESC ");
					$linha = mysql_fetch_array($pega_dados);
				?>
				<form style="    margin: 10px;" action="#" method="post">
					<h1><i>n</i> = 
						<input type="text" name="txValor" placeholder="<?php echo $linha[2]; ?>" style="    font-size: 24px;    height: 30px; width: 76px;   line-height: 20px;    margin-bottom: 0;    padding: 0 6px;"> 
						<input type="submit" class="btn btn-success"  value="Redefinir" name="btnTX">
					</h1>
				</form>
			</div>
		</div>
	</div>
	<div class="accordion-group">
		<div class="accordion-heading">
			<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion3" href="#collapseThree">
				Escolha de Função de Transferência
			</a>
		</div>
		<div id="collapseThree" class="accordion-body collapse">
			<div class="accordion-inner">
				<?php 
				 		
					$pega_dados = $Obj_Conexao->Consulta("select * from funcTransferencia WHERE atvFunc = 1  ");
					$linha = mysql_fetch_array($pega_dados);
				?>
				<form method="post" action="#">
				<label class="radio">
				<input type="radio" name="optionsRadios" id="optionsRadios1" value="1" <?php if($linha[0]==1) echo "checked"; ?>>
				&fnof;(x) = 	Função Tangente Hiperbólica
				</label>
				<label class="radio">
				<input type="radio" name="optionsRadios" id="optionsRadios2" value="2" <?php if($linha[0]==2) echo "checked"; ?>>
				&fnof;(x) = 	Função Sigmóide
				</label>
				<input type="submit" class="btn btn-success"  value="Redefinir" name="btnFuncao">
				</form>
			</div>
		</div>
	</div>
</div>

</div>


<?php
include("footer.php");
?>

