<?php
 		//include "functions/banco.php"; 
 		include "rna.php"; 
 		$objretorno = new rna();
      	$rna = new rna();
 		include "functions/functions.php";   
  		$Obj_Conexao = new CONEXAO();
?>
<?php include("header.php");?>
<div class="container">
		<ul class="nav nav-tabs">
  			<li class="active">
    			<a href="#">Listagem de Ações</a>
  			</li>
  			 <li class="">
    			<a href="consultaRapida.php">Consulta Rápida</a>
  			</li>
  			
		</ul>
	<form ction="#" method="post" name="gravaacao" class="form-inline">
	    <input  style="    height: 30px;width: 120px;" type="text" class="input-small" placeholder="Codigo da Ação" name="codigoAcao">
	    <input style="    height: 30px;width: 200px;" type="text" class="input-small" placeholder="Nome da Ação" name="nomeAcao">
	    <button type="submit" class="btn" name="gravaAcao">Incluir Ação</button>
    </form>

    <?php
    		if(isset($_GET["exclui"])){
    			$codigo = $_GET["exclui"];
    			$Obj_Conexao->Grava("DELETE FROM acoes WHERE idAcao=$codigo");
							echo "<div class='alert alert-success'><button class='close' data-dismiss='alert' type='button'>×</button>Código Removido Com Sucesso da Base de Dados.</div>";

    		}
    		if(isset($_POST["gravaAcao"])){
    			$codAcao = $_POST["codigoAcao"];
    			$nomeAcao = $_POST["nomeAcao"];
    			if($codAcao=="" || $nomeAcao==""){
    				echo "<div class='alert alert-error'><button class='close' data-dismiss='alert' type='button'>×</button>Dados Incompletos!</div>";
		
    			}else{
    				$exists = $Obj_Conexao->Consulta("SELECT * FROM acoes WHERE codigoAcao = '$codAcao'");
    				$ex = mysql_fetch_array($exists);			
	    			if($ex[0] != ""){
	    				echo "<div class='alert'><button class='close' data-dismiss='alert' type='button'>×</button>Ação já faz parte da base de dados</div>";
    				}
    				else{
    					include("clBusca.php");
    					$cotacao =  new CotacaoBovespa();
						$cotacao =  CotacaoBovespa::find($codAcao);
    					if($cotacao->codigo=="" || $cotacao->ultimoValor=="")
							echo "<div class='alert alert-error'><button class='close' data-dismiss='alert' type='button'>×</button>Ação  Não Encontrada. Certifique os Parâmetros de Busca</div>";
						else{
							$Obj_Conexao->Grava("INSERT INTO acoes(`nomeAcao`, `codigoAcao`)  VALUES('$nomeAcao','$codAcao')");
							echo "<div class='alert alert-success'><button class='close' data-dismiss='alert' type='button'>×</button>Código Incluído Com Sucesso na Base de Dados.</div>";
						}
					}
				}
			}
	 ?>
	<table class="table table-striped" style="    text-align: center;">
    <tr><td>#</td><td>Codigo</td><td>Ação</td><td>Último Valor</td><td>Data Última Leitura</td><td>Variação do dia</td><td>Predição</td><td>Ver Gráfico Evolutivo</td><td>Excluir</td></tr>
    <?php

		$pega_dados = $Obj_Conexao->Consulta("select * from acoes");
		$retorno = mysql_num_rows($pega_dados);

		if($retorno == 0 ){
	          print("<center>Erro ao carregar as informações !!<br>");
		}else{
			 $penultimo=0.0;

			for ($i = 0; $i < $retorno; ++$i){
				
                  $linha = mysql_fetch_array($pega_dados);
                  $id = $linha[0];
                  $nome = $linha[1];
				  $codigo = $linha[2];
				  $getUltimovalor = $Obj_Conexao->Consulta("select * from leitura Where acaoLeitura={$id} Order By idLeitura DESC");
				  $ult = mysql_fetch_array($getUltimovalor);
				  $predicao = getPredicao($id);
				 // echo $ult[7];
            echo "<tr>
				   <td>".($i+1)."</td><td>".$codigo."</td><td>".$nome."</td><td>".$ult[2]."</td><td>".$ult[3]."</td><td>".(($ult[7]-$ult[4])>0?'<font color=green>'.($ult[7]-$ult[4]).'</font>':'<font color=red>'.($ult[7]-$penultimo).'</font>')."</td><td>".($predicao>round((float)$ult[2],2)?'<font color=green><i class="icon-arrow-up"></i> '.$predicao.'</font>':'<font color=red><i class="icon-arrow-down"></i> '.$predicao.'</font>')."</td><td><a class='various example'  rel='tooltip' data-original-title='Ver gráfico evolutivo da ação ".$codigo."'  href='graficos/meu.php?codAcao=".$id."'><img src='img/graph.ico'></a></td><td><a href='acoes.php?exclui=".$id."'><img src='img/delete2.ico' style='width:25px;' alt='Excluir Ação ".$codigo."' title='Excluir Ação ".$codigo."'></a></td>
			     </tr>";
			      $penultimo = $ult[7];
	       }

 		}

		?>	
    
    </table>
    </div>
		
				

			
	<?php

include("footer.php");
?>