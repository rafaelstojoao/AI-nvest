<?php
 		include "functions/banco.php";  
  		$Obj_Conexao = new CONEXAO();
?>
<?php include("header.php");?>
<div class="container">
		<ul class="nav nav-tabs">
  			<li class="">
    			<a href="acoes.php">Listagem de Ações</a>
  			</li>
  			 <li class="active">
    			<a href="#">Consulta Rápida</a>
  			</li>
  			
		</ul>
<form name="consultaAcao" action="" method="post"  >
		<label for="codAcao">Insira Aqui o Código da Ação...</label><input style="    height: 30px;width: 120px;"  type="text" class="input-small" placeholder="Codigo da Ação" name="codAcao" value="" />
		<input type="submit" class="btn"  name="btnConsultaAcao" value="Consultar" />
	</form>
</div>


<?php
if(isset($_POST["btnConsultaAcao"])){
	$codigo = $_POST["codAcao"];
	include("clBusca.php");
	$cotacao =  new CotacaoBovespa();
	$cotacao =  CotacaoBovespa::find($codigo);

	echo "<div class='alert'><button class='close' data-dismiss='alert' type='button'>×</button>A cotação obita da ação".$cotacao->codigo."  foi: ".$cotacao->ultimoValor." em: ".$cotacao->data.$cotacao->hora." com variação de : ".$cotacao->oscilacao."</div><br /><br />";
	
  		include "banco.php";  
  		$Obj_Conexao = new CONEXAO();
		$Obj_Conexao->Grava("INSERT INTO leitura(`acaoLeitura`, `valorLeitura`, `dataLeitura`)  VALUES('$codigo','$cotacao->ultimoValor',NOW())");

}?>
    </div>
		
				

			
	<?php

include("footer.php");
?>