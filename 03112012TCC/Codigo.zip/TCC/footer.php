<div id="footer">
	<div class="bs-docs-example tooltip-demo">
            <ul class="bs-docs-tooltip-examples" >
              	<li><a data-placement="top" class="example" rel="tooltip" href="index.php" data-original-title="Voltar ao Início">Home</a></li>
            	<li><a target="_blank" data-placement="top" class="example" rel="tooltip" href="http://www.fct.unesp.br" data-original-title="Trabalho de Conclusão de Curso - FCT Unesp Presidente Prudente. Dezembro de 2012">FCT - Unesp Presidente Prudente - SP</a></li>
            </ul>
          </div>
</div>
</body>
</html>