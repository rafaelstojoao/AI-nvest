<!doctype html>
<?php 
    $siteCaminho = "http://localhost/TCC/TCC/"; 

?>

<html itemscope="itemscope" itemtype="http://schema.org/WebPage">
	<head> 
	 <meta charset="utf-8">
     <title>nome do projeto</title>
	 <link href="<?php echo $siteCaminho; ?>bootstrap/css/bootstrap.min.css" rel="stylesheet">
   <link href="<?php echo $siteCaminho; ?>bootstrap/css/docs.css" rel="stylesheet">
	 <script src="<?php echo $siteCaminho; ?>functions/jquery.js"></script>
    <script src="<?php echo $siteCaminho; ?>bootstrap/js/bootstrap.min.js"></script>
    <script src="<?php echo $siteCaminho; ?>bootstrap/js/tooltip.js"></script>
    <script src="<?php echo $siteCaminho; ?>bootstrap/js/dropdown.js"></script>

      <!-- Add fancyBox main JS and CSS files -->
  <script type="text/javascript" src="<?php echo $siteCaminho; ?>functions/fancybox/source/jquery.fancybox.js?v=2.1.3"></script>
  <link rel="stylesheet" type="text/css" href="<?php echo $siteCaminho; ?>functions/fancybox/source/jquery.fancybox.css?v=2.1.2" media="screen" />

	
	<style type="text/css">
      body {
        padding-top: 60px;
        padding-bottom: 40px;
      }
    </style>
<script type="text/javascript">
$(document).ready(function() {
  // put all your jQuery goodness in here.
 $(".various").fancybox({
    maxWidth  : 800,
    maxHeight : 600,
    fitToView : false,
    width   : '70%',
    height    : '70%',
    autoSize  : false,
    closeClick  : false,
    openEffect  : 'none',
    closeEffect : 'none'
  });
    
  $('.example').tooltip();
});
</script>
    </head>
	<body>
		
		<div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </a>
          <a class="brand" href="#"><img src="img/unespL.png"> AI-nvest</a>
          <div class="nav-collapse collapse">
            <ul class="nav">
              <li class="active"><a href="<?php echo $siteCaminho; ?>">Início</a></li>
              <li ><a href="<?php echo $siteCaminho; ?>acoes.php">Ações</a></li>
			  <li ><a href="<?php echo $siteCaminho; ?>configuracoes.php">Configurações</a></li>
 
              
                </ul>
              </li>
            </ul>
           
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>