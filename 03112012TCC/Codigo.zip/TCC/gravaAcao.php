<?php
include "header.php";
include "functions/banco.php";  
$Obj_Conexao = new CONEXAO();


	

error_reporting(E_ALL ^ E_NOTICE);
require_once 'excelReader/excel_reader2.php';
$data = new Spreadsheet_Excel_Reader("excelReader/petr4.xls");

for( $i=$data->rowcount($sheet_index=0); $i >=1 ; $i-- ){
   $dataLeitura = explode("/",$data->val($i, 1));
   $dataLeitura =  date('Y-m-d',mktime(0,0,0,$dataLeitura[0],$dataLeitura[1],$dataLeitura[2]))."<br/>";
        // echo $data->val($i, 1) . "-" . $data->val($i, 2). "-" . $data->val($i, 3)."-" . $data->val($i, 4)."-" . $data->val($i, 5)."-" . $data->val($i, 6)."-" . $data->val($i, 7)."<br/>";
    $Obj_Conexao->Grava("INSERT INTO leitura(`acaoLeitura`, `valorLeitura`, `dataLeitura`, `abertura`, `maxima`, `minima`, `fechamento`) 
                       VALUES('2',{$data->val($i, 5)},'{$dataLeitura}',{$data->val($i, 2)},{$data->val($i, 3)},{$data->val($i, 4)},{$data->val($i, 5)})");
    echo "<div class='alert alert-success'><button class='close' data-dismiss='alert' type='button'>×</button>Código Incluído Com Sucesso na Base de Dados.</div>";
    }


	
	//$rna->treinamento(3.45, $pesos);
?>