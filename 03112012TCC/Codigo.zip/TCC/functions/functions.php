<?php

	function random_float ($min,$max) {
        return ($min+lcg_value()*(abs($max-$min)));
      }

  	function getPredicao($codAcao){
 
  	  $Obj_Conexao = new CONEXAO();
      $idAcao = $codAcao;
$objretorno = new rna();
      	$rna = new rna();


      $pega_dados = $Obj_Conexao->Consulta("select * from numNeuronios ORDER BY idConfig DESC ");
      $linha = mysql_fetch_array($pega_dados);
      $numNeuronios= $linha[1];
  		$pesos = array();


      // //$numNeuronios =10;
      for($j=0;$j<$numNeuronios*2;$j++){
         $pesos[$j] = random_float(-1.0,1.0);
      }



      $pega_dados = $Obj_Conexao->Consulta("select * from leitura WHERE  acaoLeitura=".$idAcao." ORDER By idLeitura ASC ");
      $retorno = mysql_num_rows($pega_dados);

      if($retorno == 0 ){
              print("<center>Erro ao carregar as informações !!<br>");
      }else{
        $predicao = 0;
        for ($i = 0; $i < $retorno; ++$i){
                    $linha = mysql_fetch_array($pega_dados);
                     $id = $linha[0];
                    $leitura = $linha[2];
                     $codigo = $linha[2];
                    $objretorno = $rna->predicao($leitura,$pesos, $leitura);
                   
                    $pesos = $objretorno->p;
                    $vars .= "  d1.push([".$i.",".$leitura."]); d2.push([".$i.",".$predicao."]); ";
                    $predicao = $objretorno->obtido;
        }

      	return round($predicao,2);
      }
  }
?>