  <?php

  class CONEXAO{
		  var $usuario = "root";
          var $senha = "root";
          var $sid = "localhost";
	      var $banco = "tccBanco";
          var $consulta = "";
		  var $sql = "";
		  var $link = "";  	
  		
  		
  	function CONEXAO(){
	  		$this->Conecta();
  	}

  	function Conecta(){

  		$this->link = mysql_connect($this->sid,$this->usuario,$this->senha);
  		if (!$this->link){
  			die("Problema na Conexão com o Banco de Dados");
  		}
  		elseif (!mysql_select_db($this->banco,$this->link)){
  			die("Problema na Conexão com o Banco de Dados");
  		}

  	}
	
	function Consulta($consulta){
          	$this->consulta = $consulta;
            
	  		if ($resultado = mysql_query($this->consulta,$this->link)){
				return $resultado;
			} 
			else {
	  			return 0;
	  		}

  	}
	
	function Grava($sql){
          	$this->sql = $sql;
	  		mysql_query($this->sql,$this->link);
	
	
	}
    function Altera($sql){
            $this->sql = $sql;
        if(mysql_query($this->sql,$this->link)) return true;
        else return false;
  
  
  }
	
	function Desconecta(){
  			return mysql_close($this->link);
  	}
  }
?>
