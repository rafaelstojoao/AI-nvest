<?php
$grObtidos = array();
	$grDesejados = array();

include "rna.php"; 

function random_float ($min,$max) {
   return ($min+lcg_value()*(abs($max-$min)));
}
$rna = new rna();
$pesos = array();

$numNeuronios =50;
for($j=0;$j<$numNeuronios;$j++){
	 $pesos[$j] = random_float(-1.0,1.0);
}


	

error_reporting(E_ALL ^ E_NOTICE);
require_once 'excelReader/excel_reader2.php';
$data = new Spreadsheet_Excel_Reader("excelReader/arquivoTreinamento2.xls");
$retorno =  new rna();
for( $i=1; $i <= $data->rowcount($sheet_index=0); $i++ ){
        //echo $data->val($i, 1) . "-" . $data->val($i, 2)."<br/>";
    $retorno = $rna->predicao($data->val($i, 1),$pesos, $data->val($i, 2));
    $pesos = $retorno->p;
    $predicao = $retorno->obtido;
    }
echo $predicao;

	
	//$rna->treinamento(3.45, $pesos);
?>