<?php include "../header.php";?>
  
    <style type="text/css">
      body {
        margin: 0px;
        padding: 0px;
      }
#container {
    height: 384px;
    margin: 100px auto;
    width: 600px;
}
    </style>
  <?php //   error_reporting(E_ALL ^ E_NOTICE);
// require_once '../excelReader/excel_reader2.php';
// $data = new Spreadsheet_Excel_Reader("../excelReader/ambv3.xls");
 $vars = "";
// for( $i=1; $i <= $data->rowcount($sheet_index=0); $i++ ){
//       //$vars .= "  d1.push([".$i.",".($data->val($i, 1))."]); d2.push([".$i.",".($data->val($i, 2))."]); ";
//     }
//     //echo $vars;
//     $valor = 40;
?>
<?php // leitura do banco de dados
      include "../rna.php";  
      $Obj_Conexao = new CONEXAO();
      $idAcao = $_GET["codAcao"];


      function random_float ($min,$max) {
        return ($min+lcg_value()*(abs($max-$min)));
      }
      $rna = new rna();
      $objretorno = new rna();
      $pesos = array();

      $pega_dados = $Obj_Conexao->Consulta("select * from numNeuronios ORDER BY idConfig DESC ");
      $linha = mysql_fetch_array($pega_dados);
      $numNeuronios= $linha[1];
       $pega_dados = $Obj_Conexao->Consulta("select * from acoes Where idAcao=".$idAcao." ORDER BY idConfig DESC ");
      $dadosAcao = mysql_fetch_array($pega_dados);
      $nome= $dadosAcao[1];
      $codigoAcao= $dadosAcao[2];


      //$numNeuronios =10;
      for($j=0;$j<$numNeuronios*2;$j++){
         $pesos[$j] = random_float(-1.0,1.0);
      }



      $pega_dados = $Obj_Conexao->Consulta("select * from leitura WHERE  acaoLeitura=".$idAcao);
      $retorno = mysql_num_rows($pega_dados);

      if($retorno == 0 ){
              print("<center>Erro ao carregar as informações !!<br>");
      }else{
        $predicao = 0;
        for ($i = 0; $i < $retorno; ++$i){
                    $linha = mysql_fetch_array($pega_dados);
                    $id = $linha[0];
                    $leitura = $linha[2];
                    $codigo = $linha[2];
                    $objretorno = $rna->predicao($leitura,$pesos, $leitura);
                    
                    $pesos = $objretorno->p;
                    $vars .= "  d1.push([".$i.",".$leitura."]); d2.push([".$i.",".$predicao."]); ";
                    $predicao = $objretorno->obtido;
        }
      }
?>

    <div id="container"></div>
    <!--[if IE]>
    <script type="text/javascript" src="/static/lib/FlashCanvas/bin/flashcanvas.js"></script>
    <![endif]-->
    <script type="text/javascript" src="flotr2.min.js"></script>
<script type='text/javascript'>
      (function () {

        var
          container = document.getElementById('container'),
          data, graph, offset, i;

        // Draw a sine curve at time t
(function basic(container) {

  var
    d1    = [],
    d2    = [],
    options,
    graph,
    i, x, o;

 // for (i = 0; i < 100; i++) {
 //     x = start+(i*1000*3600*24*36.5);
 //     d1.push([i,i]);
 //     d2.push([i,i]);
 //   }
<?php  echo $vars; ?>


options = {
    xaxis : {
      mode : 'x', 
      labelsAngle : 45
    },
    selection : {
      mode : 'x'
    },
    HtmlText : false,
    title : ' Histórico de Leituras(#leitura X valor)'
  };
        
  // Draw graph with default options, overwriting with passed options
  function drawGraph (opts) {

    // Clone the options, so the 'options' variable always keeps intact.
    o = Flotr._.extend(Flotr._.clone(options), opts || {});

    // Return a new graph.
    return Flotr.draw(
      container,
      [ d1 ,d2],
      o
    );
  }

  
  graph = drawGraph();      
        
  Flotr.EventAdapter.observe(container, 'flotr:select', function(area){
    // Draw selected area
    graph = drawGraph({

      xaxis : { min : area.x1, max : area.x2, mode : 'x', labelsAngle : 45 },
      yaxis : { min : area.y1, max : area.y2 }
    });
  });
        
  // When graph is clicked, draw the graph with default area.
  Flotr.EventAdapter.observe(container, 'flotr:click', function () { graph = drawGraph(); });
})(document.getElementById('container'));

        //animate(start);
      })();
    </script>
<?php include "../footer.php"; ?>